const forms = document.querySelector(".contact"),
pwShowHide = document.querySelectorAll(".imghideeye")
pwHide = document.querySelectorAll(".imgeye");
links = document.querySelectorAll(".link");

pwShowHide.forEach( eyeIcon =>{
    eyeIcon.addEventListener("click", () =>{
        let pwFields = eyeIcon.parentElement.parentElement.querySelectorAll(".password");
        pwFields.forEach(password =>{
            if(password.type === "password"){
                password.type = "text";
                
                return;
            }
            password.type= "password";
        
        })
    })
})

links.forEach(link=>{
    link.addEventListener("click", e =>{
        e.preventDefault();
        forms.classList.toggle("show-signup");
    })
})
